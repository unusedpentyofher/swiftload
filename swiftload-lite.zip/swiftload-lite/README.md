# SwiftLoad Lite

A lightweight, mobile-first direct-file download manager prototype.

## Run on Android
1. Extract `swiftload-lite.zip` using your file manager.
2. Open `index.html` in Chrome. Some browser features (especially clipboard and downloads) work best when served over HTTPS.
3. For a hosted preview, upload the three files (`index.html`, `styles.css`, `app.js`) to a static host such as GitHub Pages or Cloudflare Pages.

## Files
- `index.html` — structure and controls
- `styles.css` — responsive dark UI
- `app.js` — URL validation, fetch workflow, progress, filtering, error handling

## Important browser limitations
- Only direct, public file URLs are in scope. This is not a universal website downloader.
- Browser `fetch()` can be blocked by cross-origin resource sharing (CORS), even if a URL opens in a normal tab.
- If CORS blocks the request, SwiftLoad reports the issue and offers an “Open link” action. It does not claim the file was downloaded.
- Accurate progress depends on a readable response and, often, a `Content-Length` header.
- Large files are buffered in browser memory before being handed to Chrome, so this prototype is not ideal for very large files or low-memory devices.
- The browser/host controls where a file is saved and may ignore the suggested filename.
- The list is session-only: there is no database or persistent history.
- The app rejects common local/private IP address forms, but browser-only validation is not a complete security boundary. A real public service would need server-side SSRF protections.

No login, paid API, database, or external backend is included.
