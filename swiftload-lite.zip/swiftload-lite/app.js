(() => {
  const $ = (s) => document.querySelector(s);
  const form = $('#downloadForm');
  const input = $('#urlInput');
  const typeSelect = $('#typeSelect');
  const downloadBtn = $('#downloadBtn');
  const statusBox = $('#statusBox');
  const list = $('#downloadsList');
  const emptyState = $('#emptyState');
  const clearBtn = $('#clearBtn');
  const countText = $('#downloadCount');
  const countAll = $('#countAll');
  const tabs = [...document.querySelectorAll('.tab')];
  let downloads = [];
  let activeFilter = 'All';
  let activeController = null;

  const extensionMap = {
    Video: ['mp4','webm','mov','m4v','mkv','avi','mpeg','mpg','3gp'],
    Audio: ['mp3','m4a','aac','ogg','opus','wav','flac'],
    Images: ['jpg','jpeg','png','gif','webp','svg','bmp','avif','heic'],
    Documents: ['pdf','txt','doc','docx','xls','xlsx','ppt','pptx','csv','rtf','zip','rar','7z']
  };

  function getUrl() {
    const raw = input.value.trim();
    if (!raw) throw new Error('Paste a direct file URL first.');
    let url;
    try { url = new URL(raw); } catch { throw new Error('That URL does not look valid. Include https:// or http://.'); }
    if (!['http:', 'https:'].includes(url.protocol)) throw new Error('Only http:// and https:// links are supported.');
    if (url.username || url.password) throw new Error('URLs containing embedded usernames or passwords are not supported.');
    const host = url.hostname.toLowerCase();
    if (host === 'localhost' || host.endsWith('.localhost') || host === '::1' ||
        /^127\./.test(host) || /^10\./.test(host) || /^192\.168\./.test(host) ||
        /^169\.254\./.test(host) || /^172\.(1[6-9]|2\d|3[01])\./.test(host)) {
      throw new Error('Local and private-network addresses are not supported.');
    }
    return url;
  }

  function filenameFrom(url, disposition) {
    if (disposition) {
      const utf = disposition.match(/filename\*=UTF-8''([^;]+)/i);
      if (utf) { try { return cleanName(decodeURIComponent(utf[1].replace(/["']/g, ''))); } catch {} }
      const basic = disposition.match(/filename="?([^";]+)"?/i);
      if (basic) return cleanName(basic[1]);
    }
    let tail = url.pathname.split('/').filter(Boolean).pop() || 'download';
    try { tail = decodeURIComponent(tail); } catch {}
    return cleanName(tail);
  }

  function cleanName(name) {
    return (name || 'download').replace(/[\\/:*?"<>|\\u0000-\\u001f]/g, '_').slice(0, 160) || 'download';
  }

  function categoryFor(name, contentType) {
    const forced = typeSelect.value;
    if (forced !== 'auto') return forced;
    const ext = (name.split('.').pop() || '').toLowerCase();
    for (const [category, exts] of Object.entries(extensionMap)) if (exts.includes(ext)) return category;
    const mime = (contentType || '').toLowerCase();
    if (mime.startsWith('video/')) return 'Video';
    if (mime.startsWith('audio/')) return 'Audio';
    if (mime.startsWith('image/')) return 'Images';
    if (mime.includes('pdf') || mime.includes('document') || mime.includes('text/')) return 'Documents';
    return 'Other';
  }

  function showStatus(message, kind = '', progress = null) {
    statusBox.hidden = false;
    statusBox.className = 'status-box' + (kind ? ' ' + kind : '');
    statusBox.replaceChildren();
    const text = document.createElement('div');
    text.textContent = message;
    statusBox.append(text);
    if (progress !== null) {
      const track = document.createElement('div');
      track.className = 'progress-track';
      const fill = document.createElement('div');
      fill.className = 'progress-fill';
      fill.style.width = Math.max(0, Math.min(100, progress)) + '%';
      track.append(fill);
      statusBox.append(track);
    }
  }

  function hideStatus() { statusBox.hidden = true; statusBox.className = 'status-box'; statusBox.replaceChildren(); }

  function prettyBytes(bytes) {
    if (!Number.isFinite(bytes) || bytes < 0) return 'Size unknown';
    if (bytes < 1024) return bytes + ' B';
    const units = ['KB','MB','GB','TB'];
    let n = bytes / 1024, i = 0;
    while (n >= 1024 && i < units.length - 1) { n /= 1024; i++; }
    return n.toFixed(n >= 100 ? 0 : 1) + ' ' + units[i];
  }

  function render() {
    list.replaceChildren();
    const filtered = downloads.filter(d => activeFilter === 'All' || d.category === activeFilter);
    if (!filtered.length) {
      const empty = emptyState.cloneNode(true);
      empty.hidden = false;
      empty.querySelector('strong').textContent = activeFilter === 'All' ? 'Nothing here yet' : `No ${activeFilter.toLowerCase()} yet`;
      empty.querySelector('p').textContent = activeFilter === 'All'
        ? 'Your downloads will show up here when you start one.'
        : `Files categorized as ${activeFilter.toLowerCase()} will appear here.`;
      list.append(empty);
    } else {
      for (const d of filtered) {
        const card = document.createElement('article');
        card.className = 'file-item';
        const icon = document.createElement('div');
        icon.className = 'file-icon ' + d.category;
        icon.textContent = ({Video:'VID',Audio:'AUD',Images:'IMG',Documents:'DOC',Other:'FILE'})[d.category] || 'FILE';
        const main = document.createElement('div'); main.className = 'file-main';
        const name = document.createElement('div'); name.className = 'file-name'; name.textContent = d.name; name.title = d.name;
        const meta = document.createElement('div'); meta.className = 'file-meta';
        const cat = document.createElement('span'); cat.textContent = d.category;
        const size = document.createElement('span'); size.textContent = d.size ? prettyBytes(d.size) : 'Size unknown';
        meta.append(cat, document.createTextNode('•'), size);
        const st = document.createElement('div'); st.className = 'file-status'; st.textContent = d.status;
        main.append(name, meta, st);
        const actions = document.createElement('div'); actions.className = 'file-actions';
        const open = document.createElement('button'); open.type='button'; open.textContent='Open link';
        open.addEventListener('click', () => window.open(d.url, '_blank', 'noopener,noreferrer'));
        const remove = document.createElement('button'); remove.type='button'; remove.textContent='Remove';
        remove.addEventListener('click', () => { downloads = downloads.filter(x => x.id !== d.id); render(); });
        actions.append(open, remove);
        card.append(icon, main, actions); list.append(card);
      }
    }
    countAll.textContent = downloads.length;
    countText.textContent = downloads.length === 0 ? 'No downloads yet' : `${downloads.length} item${downloads.length === 1 ? '' : 's'} in this session`;
    clearBtn.disabled = downloads.length === 0;
    tabs.forEach(tab => {
      const active = tab.dataset.filter === activeFilter;
      tab.classList.toggle('active', active);
      tab.setAttribute('aria-selected', String(active));
    });
  }

  function addDownload(entry) { downloads.unshift(entry); render(); }

  async function startDownload(url) {
    const entry = {id: Date.now() + Math.random(), url: url.href, name: filenameFrom(url), category: categoryFor(filenameFrom(url), ''), size: 0, status: 'Starting…'};
    addDownload(entry);
    downloadBtn.disabled = true;
    downloadBtn.querySelector('span').textContent = 'Starting…';
    showStatus('Checking whether this server allows browser downloads…');
    activeController = new AbortController();
    try {
      // A fetch allows honest progress only when CORS permits access.
      const response = await fetch(url.href, {method: 'GET', mode: 'cors', credentials: 'omit', signal: activeController.signal});
      if (!response.ok) throw new Error(`The server returned HTTP ${response.status}.`);
      if (response.type === 'opaque') throw new Error('The server did not expose the file to the browser.');
      const disposition = response.headers.get('content-disposition');
      const contentType = response.headers.get('content-type') || '';
      const name = filenameFrom(url, disposition);
      const size = Number(response.headers.get('content-length')) || 0;
      entry.name = name; entry.size = size; entry.category = categoryFor(name, contentType);
      const isLikelyPage = contentType.includes('text/html') && !/\.(html?|xhtml)$/i.test(url.pathname);
      if (isLikelyPage) throw new Error('This link returned a webpage, not a direct file. Try a direct file URL.');
      render();
      let blob;
      if (response.body && response.body.getReader) {
        const reader = response.body.getReader();
        const chunks = [];
        let received = 0;
        while (true) {
          const {done, value} = await reader.read();
          if (done) break;
          chunks.push(value); received += value.byteLength;
          const percent = size > 0 ? Math.min(99, received / size * 100) : null;
          entry.status = percent === null ? `Received ${prettyBytes(received)}…` : `Downloading · ${Math.round(percent)}%`;
          showStatus(percent === null ? `Downloading ${name} · ${prettyBytes(received)} received` : `Downloading ${name} · ${Math.round(percent)}%`, '', percent);
          render();
        }
        blob = new Blob(chunks, {type: contentType || 'application/octet-stream'});
      } else {
        blob = await response.blob();
      }
      if (!blob.size) throw new Error('The server returned an empty file, so no download was saved.');
      const objectUrl = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = objectUrl; a.download = name; a.style.display = 'none';
      document.body.append(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(objectUrl), 60_000);
      entry.name = name; entry.size = blob.size; entry.status = 'Download handed to browser';
      showStatus(`Download started for ${name}. Check your browser’s download tray; saving behavior depends on Chrome and the server.`, 'success', 100);
      render();
    } catch (err) {
      if (err.name === 'AbortError') {
        entry.status = 'Cancelled'; showStatus('Download cancelled.', 'error');
      } else {
        // Do not claim success for fallback: direct navigation cannot be verified.
        entry.status = 'Browser fallback available';
        const message = err instanceof TypeError
          ? 'Browser access was blocked (often CORS). The file could not be fetched or progress verified. You can try opening the direct link in the browser instead.'
          : err.message || 'The download failed.';
        showStatus(message + ' Use “Open link” in the list to try the server’s own download behavior; success cannot be verified here.', 'error');
      }
      render();
    } finally {
      activeController = null;
      downloadBtn.disabled = false;
      downloadBtn.querySelector('span').textContent = 'Download file';
    }
  }

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    hideStatus();
    let url;
    try { url = getUrl(); } catch (err) { showStatus(err.message, 'error'); input.focus(); return; }
    await startDownload(url);
  });

  $('#pasteBtn').addEventListener('click', async () => {
    try {
      if (!navigator.clipboard || !navigator.clipboard.readText) throw new Error('Clipboard access is unavailable in this browser.');
      input.value = await navigator.clipboard.readText();
      input.focus();
      showStatus('Link pasted. Check it, then tap Download file.');
    } catch (err) {
      showStatus('Could not read clipboard automatically. Long-press the URL field and choose Paste.', 'error');
    }
  });

  tabs.forEach(tab => tab.addEventListener('click', () => { activeFilter = tab.dataset.filter; render(); }));
  clearBtn.addEventListener('click', () => { if (activeController) activeController.abort(); downloads = []; render(); hideStatus(); });
  input.addEventListener('input', () => { if (!statusBox.hidden) hideStatus(); });
  render();
})();